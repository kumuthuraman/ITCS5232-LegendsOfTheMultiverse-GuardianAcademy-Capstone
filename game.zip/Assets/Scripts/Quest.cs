using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class Quest
{
    public string title; // Quest title
    public string description; // Quest description
    public bool isCompleted; // Flag to track quest completion
    public int objectiveValue; // Number of items needed to complete the quest

    public Quest()
    {
        this.title = "";
        this.description = "";
        this.objectiveValue = 100;
        this.isCompleted = false; // Quest starts incomplete
    }
    public Quest(string title, string description, int objectiveValue)
    {
        this.title = title;
        this.description = description;
        this.objectiveValue = objectiveValue;
        this.isCompleted = false; // Quest starts incomplete
    }
    public void CompleteQuest()
    {
        // this.title = this.title + "Completed!";
        isCompleted = true;
        // Add logic for quest rewards (e.g., give items, experience)
    }
}
