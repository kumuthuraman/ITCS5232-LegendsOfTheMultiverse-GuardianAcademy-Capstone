using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Quest_UI : MonoBehaviour
{
    public GameObject questPanel;
    public List<List_UI> quests = new List<List_UI>();
    public AudioSource src;
    public AudioClip sfx1;

    void Start()
    {
        questPanel.SetActive(false);
    }
    // Update is called once per frame
    void Update()
    {

        if (Input.GetKeyDown(KeyCode.Slash))
        {
            ToggleQuests();
        }
    }

    public void ToggleQuests()
    {
        src.clip = sfx1;
        src.Play();
        if (!questPanel.activeSelf)
        {
            questPanel.SetActive(true);
            Refresh();
        }
        else
        {
            questPanel.SetActive(false);
        }
    }

    void Refresh()
    {
        Player player = FindObjectOfType<Player>();
        // if (quests.Count == player.activeQuests.Count)
        // {
        for (int i = 0; i < quests.Count; i++)
        {
            if (i < player.activeQuests.Count)
            {
                Debug.Log(player.activeQuests[i].title);
                if (player.activeQuests[i].title != "" || player.activeQuests[i].title != null)
                {
                    quests[i].SetItem(player.activeQuests[i].title);
                }
            }
            else
            {
                quests[i].SetEmpty();
            }
        }
        // }
    }
}
