using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;
using UnityEngine.SceneManagement;

public class Player : MonoBehaviour
{
    public float moveSpeed = 5f; // Adjust the speed as needed
    private Rigidbody2D rb;
    public GameObject exitPrefab;
    // public int numCollectables = 0;
    public Inventory inventory;
    public LayerMask interactable;
    public LayerMask magic;
    private Animator animator;

    // Flag to indicate if player is in dialogue/interaction
    public bool isInteracting = false;
    // public List<Quest> activeQuests; // List to store active quests
    public List<Quest> activeQuests;

    public void AddQuest(Quest quest)
    {
        Debug.Log("add quest player");
        activeQuests.Add(quest);
        // Display UI notification or message about the offered quest
    }

    private void Awake()
    {
        inventory = new Inventory(12);
        activeQuests = new List<Quest>(7);
    }

    private void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();

        // Check if the current scene is the game scene
        if (SceneManager.GetActiveScene().name == "game")
        {
            // Use DontDestroyOnLoad to persist the player object
            DontDestroyOnLoad(gameObject);
        }
    }
    public bool isFacingRight = true;

    private void Update()
    {
        skillLevel = PlayerPrefs.GetInt("experience");
        animator.SetBool("isMoving", false);

        if (isInteracting)
        {
            rb.velocity = new Vector2(0, 0);
        }
        else
        {
            // Get input from the player
            float moveX = Input.GetAxis("Horizontal");
            float moveY = Input.GetAxis("Vertical");

            // Calculate movement direction
            Vector2 movement = new Vector2(moveX, moveY).normalized;

            // Apply movement
            rb.velocity = movement * moveSpeed;

            // Flip animation based on facing direction and movement
            if (isFacingRight && moveX < 0)
            {
                FlipAnimation();
                animator.SetBool("isMoving", true);
            }
            else if (!isFacingRight && moveX > 0)
            {
                FlipAnimation();
                animator.SetBool("isMoving", true);
            }

            // Check for spell cast in dungeon scene (assuming left mouse click)
            if ((SceneManager.GetActiveScene().name == "game" || SceneManager.GetActiveScene().name == "dungeon") && Input.GetMouseButtonDown(0))
            {
                // Raycast to check for object clicked on
                Vector2 mousePosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
                RaycastHit2D hit = Physics2D.Raycast(mousePosition, Vector2.zero, Mathf.Infinity, magic);

                if (hit.collider != null && hit.collider.gameObject.layer == LayerMask.NameToLayer("MagicObjects"))
                {
                    // Cast a spell if object is clicked
                    CastSpell(hit.point);
                }
            }
            if (SceneManager.GetActiveScene().name == "start") {
                Destroy(gameObject);
            }
        }
    }
    void FlipAnimation()
    {
        isFacingRight = !isFacingRight; // Toggle facing direction
        Vector3 newScale = transform.localScale;
        newScale.x *= -1; // Flip the X scale to reverse animation
        transform.localScale = newScale;
    }
    public int spellDamageConstant = 10; // Constant factor for spell damage
    public int skillLevel = 1; // Player's skill level (assuming it increases)
    public GameObject magicSpellPrefab; // Prefab of the spell projectile
    public float projectileSpeed = 10f; // Speed of the projectile
    private void CastSpell(Vector2 targetPoint)
    {
        // Calculate direction of the spell
        Vector2 direction = targetPoint - (Vector2)transform.position;
        direction.Normalize();

        // Instantiate the projectile prefab
        GameObject magicSpell = Instantiate(magicSpellPrefab, transform.position, Quaternion.identity);

        // Set the projectile's velocity
        magicSpell.GetComponent<Rigidbody2D>().velocity = direction * projectileSpeed;

        // Set the projectile's damage based on skill level
        Debug.Log(spellDamageConstant + (spellDamageConstant * skillLevel / 10));
        magicSpell.GetComponent<MagicSpell>().damage = spellDamageConstant + (spellDamageConstant * skillLevel / 10);
    }
}
