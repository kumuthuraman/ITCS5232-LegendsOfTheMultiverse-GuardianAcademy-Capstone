using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Magic : MonoBehaviour
{
    public int power = 20;
    public int experience = 3;
    AudioSource src;

    private void OnCollisionEnter2D(Collision2D collision)
    {
        // Get the collided object
        GameObject collidedObject = collision.gameObject;
        // Check if the collided object has a specific tag
        if (collision.gameObject.CompareTag("Magic"))
        {
            src = GetComponent<AudioSource>();
            src.Play();
            // Get the damage value from the collided object
            MagicSpell magicSpell = collidedObject.GetComponent<MagicSpell>();
            power -= magicSpell.damage;
            if (power <= 0)
            {
                int exp = PlayerPrefs.GetInt("experience");
                exp += experience;
                PlayerPrefs.SetInt("experience", exp);
                Destroy(gameObject);
            }
            // Destroy the collided object
            Destroy(collidedObject);
        }
    }

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }
}
