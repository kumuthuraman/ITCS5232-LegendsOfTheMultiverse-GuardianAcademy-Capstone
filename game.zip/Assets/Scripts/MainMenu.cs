using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenu : MonoBehaviour
{
    public AudioSource src;
    public AudioClip sfx1;
    public void GoToScene(string sceneName) {
        src.clip = sfx1;
        src.Play();
        Debug.Log(sceneName);
        SceneManager.LoadScene(sceneName, LoadSceneMode.Single);
    }

    public void QuitApp() {
        Application.Quit();
        Debug.Log("Application has quit.");
    }
}
