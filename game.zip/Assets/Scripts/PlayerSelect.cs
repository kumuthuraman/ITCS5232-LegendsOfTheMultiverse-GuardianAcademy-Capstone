// referenced: https://www.youtube.com/watch?v=3qlRgICRoeA
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro; // This line imports the TextMeshPro namespace

public class PlayerSelect : MonoBehaviour
{
    public GameObject[] characters;
    public string[] cnames;
    public TMP_Text clabel;
    public string[] inames;
    public TMP_Text ilabel;


    public int selectedCharacter = 0;
    public AudioSource src;
    public AudioClip sfx1;

    void Start()
    {
        clabel.text = cnames[0];
        // glabel.text = gnames[0];
        ilabel.text = inames[0];
        for (int i = 0; i < characters.Length; i++)
        {
            if (i > 0)
            {
                characters[i].SetActive(false);
                // guides[i].SetActive(false);
            }
        }
    }

    public void NextCharacter()
    {
        Debug.Log("next clicked");
        src.clip = sfx1;
        src.Play();
        characters[selectedCharacter].SetActive(false);
        // guides[selectedCharacter].SetActive(false);
        selectedCharacter = (selectedCharacter + 1) % characters.Length;
        characters[selectedCharacter].SetActive(true);
        // guides[selectedCharacter].SetActive(true);
        clabel.text = cnames[selectedCharacter];
        // glabel.text = gnames[selectedCharacter];
        ilabel.text = inames[selectedCharacter];
    }

    public void PreviousCharacter()
    {
        Debug.Log("previous clicked");
        src.clip = sfx1;
        src.Play();
        characters[selectedCharacter].SetActive(false);
        // guides[selectedCharacter].SetActive(false);
        selectedCharacter--;
        if (selectedCharacter < 0)
        {
            selectedCharacter += characters.Length;
        }
        characters[selectedCharacter].SetActive(true);
        // guides[selectedCharacter].SetActive(true);
        clabel.text = cnames[selectedCharacter];
        // glabel.text = gnames[selectedCharacter];
        ilabel.text = inames[selectedCharacter];
    }

    public void StartGame()
    {
        Debug.Log(selectedCharacter);
        src.clip = sfx1;
        src.Play();
        PlayerPrefs.SetInt("selectedCharacter", selectedCharacter);
        Debug.Log(selectedCharacter);
        // PlayerPrefs.SetInt("selectedGuide", selectedCharacter);
        PlayerPrefs.SetInt("currentHealth", 100);
        // string sceneName = "Game";
        // SceneManager.LoadScene("Game", LoadSceneMode.Single);
        SceneManager.LoadScene("game", LoadSceneMode.Single);
        // SceneManager.LoadScene(1, LoadSceneMode.Single);
    }
}


