using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class List_UI : MonoBehaviour
{
    // public Image bg;
    public TMP_Text questText;

    public void SetItem(string title) {
            // bg.color = new Color(1, 1, 1, 1);
            questText.text = title;
    }

    public void SetEmpty() {
        // bg.color = new Color(1, 1, 1, 0);
        questText.text = "";
    }
    
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
