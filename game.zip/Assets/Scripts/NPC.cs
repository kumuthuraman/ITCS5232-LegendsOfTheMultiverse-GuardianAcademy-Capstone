using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class NPC : MonoBehaviour
{
    [System.Serializable]
    public struct Conversation
    {
        [SerializeField] public string[] dialogueLine;
    }

    public string name; // NPC's name for display
    public Conversation[] dialogueLines; // 2D array of dialogue lines (conversations)
    private int currentConversationIndex = 0; // Keeps track of the current conversation

    // public string[] dialogueLines; // Array of dialogue lines
    private int currentLineIndex = 0; // Keeps track of the current dialogue line
    public GameObject dialoguePanel;
    public TMP_Text dialogueText;
    private bool dialogueActive = false;
    public Quest quest = new Quest(); // Reference to the quest offered by this NPC
    public bool hasQuest = false;
    // public bool questFirst = false;
    // public string questTitle;
    // public string questDescription;
    // public int questObjectiveValue = 0;
    public Collectable item;
    public AudioSource src;
    public AudioClip sfx1;

    void Start()
    {
        dialoguePanel.SetActive(false);
        dialogueActive = false;
        currentLineIndex = 0;
    }

    void Update()
    {
        Player player = FindObjectOfType<Player>();
        if (!hasQuest)
        {
            if (dialogueActive && Input.GetMouseButtonDown(0)) // Check for left mouse click
            {
                src.clip = sfx1;
                src.Play();
                currentLineIndex++;
                if (currentLineIndex >= dialogueLines[currentConversationIndex].dialogueLine.Length)
                {
                    // Set player interacting to false when dialogue ends
                    if (player != null)
                    {
                        player.isInteracting = false;
                    }

                    dialoguePanel.SetActive(false);
                    dialogueActive = false;
                    currentLineIndex = 0;
                }
                else
                {
                    dialogueText.text = dialogueLines[currentConversationIndex].dialogueLine[currentLineIndex];
                }
            }
        }
        else
        {
            if (dialogueActive && Input.GetMouseButtonDown(0)) // Check for left mouse click
            {
                src.clip = sfx1;
                src.Play();
                player = FindObjectOfType<Player>();  // Find Player script in scene
                if (quest.isCompleted && hasQuest)
                {
                    Debug.Log("quest complete mouse click");
                    // questFirst = true;
                    dialoguePanel.SetActive(false);
                    dialogueActive = false;
                    player.isInteracting = false;
                }
                else
                {
                    currentLineIndex++;
                    if (currentLineIndex >= dialogueLines[currentConversationIndex].dialogueLine.Length)
                    {
                        // Set player interacting to false when dialogue ends
                        if (player != null)
                        {
                            // Give quest to player (if one exists)
                            if (quest != null)
                            {
                                player.AddQuest(quest); // Assuming Player script has an AddQuest method
                                Debug.Log("Quest: " + quest.title + " given to player!");
                            }
                            player.isInteracting = false;
                        }

                        dialoguePanel.SetActive(false);
                        dialogueActive = false;
                        currentLineIndex = 0;
                        if (currentConversationIndex < dialogueLines.Length - 1)
                        {
                            currentConversationIndex++;
                        }
                    }
                    else
                    {
                        dialogueText.text = dialogueLines[currentConversationIndex].dialogueLine[currentLineIndex];
                    }
                }
            }
        }
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            Player player = other.GetComponent<Player>();
            player.isInteracting = true;
            if (hasQuest)
            {
                // quest = new Quest(questTitle, questDescription, questObjectiveValue);
                // quest.title = questTitle;
                // quest.description = questDescription;
                // quest.objectiveValue = questObjectiveValue;
                if (quest != null && player.inventory.GetItemCount(item) >= quest.objectiveValue && hasQuest) // Check collected items
                {
                    quest.CompleteQuest();
                    player.inventory.SetItemCount(item, (player.inventory.GetItemCount(item) - quest.objectiveValue));
                    Debug.Log("Quest: " + quest.isCompleted + " completed!");
                    hasQuest = false;
                    // dialogueLines[currentConversationIndex] = [""];
                    dialogueText.text = "Thank you for your help!";
                    src.clip = sfx1;
                    src.Play();
                    dialoguePanel.SetActive(true);
                    dialogueActive = true;
                    if (currentConversationIndex < dialogueLines.Length - 1)
                    {
                        currentConversationIndex++;
                    }
                    // Add logic for quest rewards (e.g., display message, give items, experience)
                }
                else
                {
                    src.clip = sfx1;
                    src.Play();
                    dialoguePanel.SetActive(true);
                    dialogueText.text = dialogueLines[currentConversationIndex].dialogueLine[0];
                    dialogueActive = true;
                }
            }
            else
            {
                src.clip = sfx1;
                src.Play();
                dialoguePanel.SetActive(true);
                dialogueText.text = dialogueLines[currentConversationIndex].dialogueLine[0];
                dialogueActive = true;
            }
        }
    }
}
