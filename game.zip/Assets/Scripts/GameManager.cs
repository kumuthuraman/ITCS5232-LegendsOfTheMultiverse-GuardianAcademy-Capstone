using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using TMPro;

public class GameManager : MonoBehaviour
{
    public GameObject[] characterPrefabs;
    public int currentHealth = 100;
    private GameObject playerObject;

    private void Awake() // Use Awake instead of Start for persistence checks
    {
        // Check if the player object already exists in the scene
        playerObject = GameObject.FindGameObjectWithTag("Player");

        if (playerObject == null) // If player doesn't exist, spawn a new one
        {
            string previousSceneName = SceneManager.GetSceneByBuildIndex(SceneManager.GetActiveScene().buildIndex - 1).name;
            if (previousSceneName != "dungeon") // Replace "dungeon" with your actual dungeon scene name
            {
                // Spawn player based on saved character selection
                Vector3 playerSpawnPosition = new Vector3(0, 0, 0); // Convert Vector2Int to Vector3 with Z set to 0
                PlayerPrefs.SetInt("experience", 1);
                int selectedCharacter = PlayerPrefs.GetInt("selectedCharacter");
                Debug.Log("Player: " + selectedCharacter);
                GameObject playerPrefab = characterPrefabs[selectedCharacter];
                playerObject = Instantiate(playerPrefab, playerSpawnPosition, Quaternion.identity);
                PlayerPrefs.SetInt("currentHealth", currentHealth);
            }
        }
        else {
            playerObject.transform.position = new Vector3(0, 0, 0);
        }
    }

    public int maxExp;
    public int winExp;
    public float updatedExp;
    public Slider expBar;
    public int playerLevel = 1;
    public TMP_Text levelText;
    public TMP_Text expText;


    void Update()
    {
        updatedExp = PlayerPrefs.GetInt("experience") % maxExp;
        expBar.value =  updatedExp;
        expText.text = PlayerPrefs.GetInt("experience").ToString();
        levelText.text = playerLevel + "";

        if (PlayerPrefs.GetInt("experience") >= maxExp) {
            playerLevel++;
            updatedExp = PlayerPrefs.GetInt("experience") % maxExp;
            maxExp += maxExp;
            expBar.maxValue = maxExp;
        }

        if (PlayerPrefs.GetInt("experience") >= winExp  && SceneManager.GetActiveScene().name == "game") {
            SceneManager.LoadScene("win", LoadSceneMode.Single);
        }
    }
}
