using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RandomCollectableSpawner : MonoBehaviour
{
    [SerializeField]
    private GameObject[] collectablePrefabs; // Array of collectable prefabs to spawn
    [SerializeField]
    private float spawnRadius = 5.0f; // Radius around the spawner for spawning
    [SerializeField]
    private float minSpawnTime = 2.0f; // Minimum time between spawns (seconds)
    [SerializeField]
    private float maxSpawnTime = 5.0f; // Maximum time between spawns (seconds)
    [SerializeField]
    private LayerMask spawnLayerMask1; // Layer to check for collisions (adjust based on your collectables' layer)
    [SerializeField]
    private LayerMask spawnLayerMask2;
    [SerializeField]
    private LayerMask spawnLayerMask3;

    private float nextSpawnTime;

    private void Start()
    {
        nextSpawnTime = Random.Range(minSpawnTime, maxSpawnTime); // Set initial spawn time
    }

    private void Update()
    {
        if (Time.time >= nextSpawnTime)
        {
            if (TrySpawnCollectable())
            {
                nextSpawnTime = Time.time + Random.Range(minSpawnTime, maxSpawnTime); // Set next spawn time
            }
        }
    }

    private bool TrySpawnCollectable()
    {
        int randomIndex = Random.Range(0, collectablePrefabs.Length); // Choose a random prefab from the array
        for (int attempt = 0; attempt < 10; attempt++) // Try up to 10 times to find a valid spawn location
        {
            Vector3 spawnPosition = transform.position + Random.insideUnitSphere * spawnRadius;
            spawnPosition.z = 0f; // Assuming collectables are in 2D space, set Z to 0

            // Check for overlap using Physics.OverlapSphere
            Collider2D[] overlapResults1 = Physics2D.OverlapCircleAll(spawnPosition, collectablePrefabs[randomIndex].GetComponent<Collider2D>().bounds.extents.x, spawnLayerMask1);
            Collider2D[] overlapResults2 = Physics2D.OverlapCircleAll(spawnPosition, collectablePrefabs[randomIndex].GetComponent<Collider2D>().bounds.extents.x, spawnLayerMask2);
            Collider2D[] overlapResults3 = Physics2D.OverlapCircleAll(spawnPosition, collectablePrefabs[randomIndex].GetComponent<Collider2D>().bounds.extents.x, spawnLayerMask3);

            if (overlapResults1.Length == 0 && overlapResults2.Length == 0 && overlapResults3.Length == 0) // No overlap found, spawn the collectable
            {
                Instantiate(collectablePrefabs[randomIndex], spawnPosition, Quaternion.identity);
                return true;
            }
        }

        // Couldn't find a valid spawn location after attempts, log a message (optional)
        Debug.LogWarning("RandomCollectableSpawner: Couldn't find a valid spawn location after 10 attempts.");
        return false;
    }
}
