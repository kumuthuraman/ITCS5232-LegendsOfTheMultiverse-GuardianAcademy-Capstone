using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Collectable : MonoBehaviour
{
    public CollectableType type;
    public Sprite icon;

    private void OnTriggerEnter2D(Collider2D collision)
    {
        Player player = collision.GetComponent<Player>();
        AudioSource src = GetComponent<AudioSource>();
        if (player)
        {
            src.Play();
            player.inventory.Add(this);
            Destroy(this.gameObject);
        }
    }
}

public enum CollectableType {
    NONE, BASICSPELLBOOK, ANCIENTTABLET, DEFENSEPOTION, MANAPOTION, MAGICPOTION, LUCKPOTION, ADVANCEDSCROLL, GLOWSHROOM, MEDICINALHERB, SILVERINGOT, GOLDINGOT, SUGARCANE
}
