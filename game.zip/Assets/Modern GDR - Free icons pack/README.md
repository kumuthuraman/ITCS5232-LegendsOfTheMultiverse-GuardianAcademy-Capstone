## Hello there, thank you for downloaded this pack c:

Before you start your project, please make sure that you have installed **TextMeshPro** and **2D Sprite (Sprite Editor)** so that the font and atlas in the package display correctly.

Within the package you will find the following items:
- A Demo scene 
- 4 ImageAtlases containing the icons (Bright, Dark and w/Background)

If you enjoyed the package, feel free to leave a review on the Asset Store
it will be appreciated <3

Good luck with your project!

Jennifer